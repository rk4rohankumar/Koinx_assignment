import React from 'react'

const GetStarted = () => {
  return (
    <>Get Started</>
  )
}

export default GetStarted