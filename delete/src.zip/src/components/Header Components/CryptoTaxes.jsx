import React from 'react'

const CryptoTaxes = () => {
  return (
    <>
        Crypto Taxes
    </>
  )
}

export default CryptoTaxes