import React from 'react'

const ResourceCenter = () => {
  return (
    <>Resource Center</>
  )
}

export default ResourceCenter