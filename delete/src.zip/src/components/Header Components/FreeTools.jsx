import React from 'react'

const FreeTools = () => {
  return (
    <>Free Tools</>
  )
}

export default FreeTools